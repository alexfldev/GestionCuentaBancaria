package EJERCICIOS;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GestionCuentaBancaria {

    // Clase CuentaBancaria
    static class CuentaBancaria {
        private double saldo;

        public CuentaBancaria(double saldoInicial) {
            this.saldo = saldoInicial;
        }

        public void depositar(double cantidad) {
            if (cantidad > 0) {
                saldo += cantidad;
            }
        }

        public void retirar(double cantidad) {
            if (cantidad > 0 && cantidad <= saldo) {
                saldo -= cantidad;
            }
        }

        public double consultarSaldo() {
            return saldo;
        }
    }

    // Método principal
    public static void main(String[] args) {
        
        JFrame frame = new JFrame("Gestión de Cuenta Bancaria");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 400);
        frame.setLayout(new BorderLayout(10, 10));

        
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new GridBagLayout()); 
        frame.add(mainPanel, BorderLayout.CENTER);

     
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10); 
        gbc.gridx = 0;
        gbc.gridy = 0;

       
        JLabel saldoLabel = new JLabel("Saldo actual: $1000.00");
        saldoLabel.setFont(new Font("Arial", Font.PLAIN, 16));
        mainPanel.add(saldoLabel, gbc);

        gbc.gridy++;
        mainPanel.add(new JLabel("Cantidad:"), gbc); 

        JTextField cantidadField = new JTextField(15);
        cantidadField.setFont(new Font("Arial", Font.PLAIN, 14));
        gbc.gridy++;
        mainPanel.add(cantidadField, gbc);

     
        JButton depositarButton = new JButton("Depositar");
        JButton retirarButton = new JButton("Retirar");
        JButton consultarButton = new JButton("Consultar saldo");

        depositarButton.setFont(new Font("Arial", Font.BOLD, 14));
        retirarButton.setFont(new Font("Arial", Font.BOLD, 14));
        consultarButton.setFont(new Font("Arial", Font.BOLD, 14));

        gbc.gridy++;
        mainPanel.add(depositarButton, gbc);
        gbc.gridy++;
        mainPanel.add(retirarButton, gbc);
        gbc.gridy++;
        mainPanel.add(consultarButton, gbc);

        
        JLabel mensajeLabel = new JLabel("");
        mensajeLabel.setFont(new Font("Arial", Font.ITALIC, 14));
        mensajeLabel.setForeground(Color.RED);
        gbc.gridy++;
        mainPanel.add(mensajeLabel, gbc);

     
        CuentaBancaria cuenta = new CuentaBancaria(1000.00);


        depositarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    double cantidad = Double.parseDouble(cantidadField.getText());
                    if (cantidad > 0) {
                        cuenta.depositar(cantidad);
                        saldoLabel.setText("Saldo actual: $" + cuenta.consultarSaldo());
                        mensajeLabel.setText("Depósito exitoso.");
                    } else {
                        mensajeLabel.setText("Cantidad inválida.");
                    }
                } catch (NumberFormatException ex) {
                    mensajeLabel.setText("Por favor, ingresa una cantidad válida.");
                }
            }
        });


        retirarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    double cantidad = Double.parseDouble(cantidadField.getText());
                    if (cantidad > 0 && cantidad <= cuenta.consultarSaldo()) {
                        cuenta.retirar(cantidad);
                        saldoLabel.setText("Saldo actual: $" + cuenta.consultarSaldo());
                        mensajeLabel.setText("Retiro exitoso.");
                    } else if (cantidad > cuenta.consultarSaldo()) {
                        mensajeLabel.setText("Fondos insuficientes.");
                    } else {
                        mensajeLabel.setText("Cantidad inválida.");
                    }
                } catch (NumberFormatException ex) {
                    mensajeLabel.setText("Por favor, ingresa una cantidad válida.");
                }
            }
        });

      
        consultarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                saldoLabel.setText("Saldo actual: $" + cuenta.consultarSaldo());
                mensajeLabel.setText("Consulta realizada.");
            }
        });

        
        frame.setLocationRelativeTo(null); 
        frame.setVisible(true);
    }
}
